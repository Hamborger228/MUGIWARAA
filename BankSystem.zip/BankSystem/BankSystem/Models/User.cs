﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel;

namespace BankSystem.Models
{

    public class User
    {

        [Key]
        public int Id { get; set; }
        [DisplayName("User Name")]
        [Required(ErrorMessage ="This field is required")]
        public string? UserName { get; set; }
        [DataType(DataType.Password)]
        [Required(ErrorMessage = "This field is required")]
        public string Pin { get; set; }
        public float Balance { get; set; }

    }
}
