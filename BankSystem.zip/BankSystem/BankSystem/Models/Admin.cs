﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BankSystem.Models
{
    public class Admin
    {
        [Key]
        public int AdminId { get; set; }
        public string? AdminName { get; set; }
        public int Password { get; set; }
    }
}
